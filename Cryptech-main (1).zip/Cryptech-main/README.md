# Cryptech

![CircleCI](https://circleci.com/gh/KOSASIH/Cryptech/tree/main.svg?style=svg)

Smart REST API's Data Connector Innovation Financial technology that provides services for all forms of banking transactions as well as digital finance and digital currency.
